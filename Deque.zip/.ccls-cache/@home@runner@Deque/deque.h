#ifndef DEQUE_H
#define DEQUE_H

#define MAX_NOME 50
#define MAX_ALUNOS 40

typedef struct {
    char nome[MAX_NOME];
} Aluno;

typedef struct {
    Aluno lista[MAX_ALUNOS];
    int inicio;
    int fim;
    int tamanho;
} Deque;

Deque* criaDeque();
void insereInicio(Deque* deque, Aluno aluno);
void insereFim(Deque* deque, Aluno aluno);
Aluno removeInicio(Deque* deque);
Aluno removeFim(Deque* deque);
void exibe(Deque* deque, int pos, char ordem);

#endif  /* DEQUE_H */
