#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "deque.h"

Deque* criaDeque() {
    Deque* deque = (Deque*)malloc(sizeof(Deque));
    deque->inicio = 0;
    deque->fim = -1;
    deque->tamanho = 0;
    return deque;
}

bool estaVazio(Deque* deque) {
    return deque->tamanho == 0;
}

void insereInicio(Deque* deque, Aluno aluno) {
    if (deque->fim == MAX_ALUNOS - 1)
        deque->fim = -1;
    deque->lista[++deque->fim] = aluno;
    deque->tamanho++;
}

void insereFim(Deque* deque, Aluno aluno) {
    if (deque->fim == MAX_ALUNOS - 1)
        deque->fim = -1;
    deque->lista[--deque->inicio] = aluno;
    deque->tamanho++;
}

Aluno removeInicio(Deque* deque) {
    Aluno aluno = deque->lista[deque->inicio++];
    if (deque->inicio == MAX_ALUNOS)
        deque->inicio = 0;
    deque->tamanho--;
    return aluno;
}

Aluno removeFim(Deque* deque) {
    Aluno aluno = deque->lista[deque->fim--];
    if (deque->fim == -1)
        deque->fim = MAX_ALUNOS - 1;
    deque->tamanho--;
    return aluno;
}

void exibe(Deque* deque, int pos, char ordem) {
    if (ordem == 'd') {
        for (int i = 0; i < deque->tamanho; i++) {
            int index = (deque->inicio + i) % MAX_ALUNOS;
            printf("%d-%s\n", index, deque->lista[index].nome);
        }
    } else if (ordem == 'i') {
        for (int i = deque->tamanho - 1; i >= 0; i--) {
            int index = (deque->inicio + i) % MAX_ALUNOS;
            printf("%d-%s\n", index, deque->lista[index].nome);
        }
    }
}

