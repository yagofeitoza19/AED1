#include <stdio.h>
#include "deque.h"

int main() {
    Deque* deque = criaDeque();

    // Exemplo de inserção de alunos na lista
    Aluno aluno1, aluno2, aluno3;
    strcpy(aluno1.nome, "Rafael Souza");
    strcpy(aluno2.nome, "Bruna Silva");
    strcpy(aluno3.nome, "Marcos Santos");

    insereInicio(deque, aluno1);
    insereFim(deque, aluno2);
    insereFim(deque, aluno3);

    // Exemplo de uso da função exibe()
    exibe(deque, 0, 'd'); // Exibe todos os alunos em ordem direta
    printf("\n");
    exibe(deque, 0, 'i'); // Exibe todos os alunos em ordem inversa

    return 0;
}

